

/***************************** Include Files *******************************/
#include "cordic_iterativa_ip.h"

/************************** Function Definitions ***************************/
